<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survey</title>
    <style>
        .container {
            text-align: center;
        }
        body {
            background-color: brown;
            color: black;
        }
        input{
            background:white;
            border-radius: 10px;
            
            

        }
        button{
            background:green;
        }
        textarea{
            background: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <?php
    $insertconf = false;
    $server = "localhost";
    $user = "root";
    $password = "";
    $dbname = "survey";

    // Create connection
    $con = new mysqli($server, $user, $password, $dbname);

    // Check connection
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    // Check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $message = $_POST['message'];

        // Insert data into database
        $sql_query = "INSERT INTO survey (name, mobile, email, age, gender, message) VALUES ('$name', '$mobile', '$email', '$age', '$gender', '$message')";

        if ($con->query($sql_query) === TRUE) {
            $insertconf = true;
        } else {
            echo "Error: " . $sql_query . "<br>" . $con->error;
        }
    }

    // Close connection
    $con->close();
    ?>

    <div class="container">
        <h1>Survey &#9997;</h1>
        <h1>Enter your details</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <input type="text" name="name" id="name" placeholder="Enter your name" required><hr>
            <input type="text" name="mobile" id="mobile" placeholder="Mobile number" required><hr>
            <input type="email" name="email" id="email" placeholder="Enter your email" required><hr>
            <input type="text" name="age" id="age" placeholder="Age" required><hr>
            <input type="radio" name="gender" value="Male" id="gender">Male
            <input type="radio" name="gender" value="Female" id="gender">Female
            <input type="radio" name="gender" value="Others" id="gender">Others<hr>

            <textarea id="message" name="message" cols="25" rows="20" placeholder="Your reply..."></textarea>
            <br>
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </form>
    </div>
</body>
</html>
