const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const tileSize = 20;
const width = 400;
const height = 400;

canvas.width = width;
canvas.height = height;

let snake = [{ x: 100, y: 100 }];
let direction = { x: 1, y: 0 };  // Initially moving right
let nextDirection = { x: 1, y: 0 };  // Handle direction change more smoothly
let food = getRandomFoodPosition();
let currentScore = 0;
let highScore = 0;
let gameOver = false;
let isPaused = false;

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw snake
    snake.forEach(segment => {
        ctx.fillStyle = 'lime';
        ctx.fillRect(segment.x, segment.y, tileSize, tileSize);
    });

    // Draw food
    ctx.fillStyle = 'red';
    ctx.fillRect(food.x, food.y, tileSize, tileSize);

    // Draw scores
    document.getElementById("current-score").textContent = `Current Score: ${currentScore}`;
    document.getElementById("high-score").textContent = `High Score: ${highScore}`;
}

function update() {
    if (gameOver || isPaused) return;

    // Update direction only when the snake moves
    direction = nextDirection;

    // Move snake
    const newHead = { x: snake[0].x + direction.x * tileSize, y: snake[0].y + direction.y * tileSize };

    // Check for wall collision
    if (newHead.x < 0 || newHead.x >= width || newHead.y < 0 || newHead.y >= height) {
        triggerGameOver();
        return;
    }

    // Check for tail collision
    if (snake.some(segment => segment.x === newHead.x && segment.y === newHead.y)) {
        triggerGameOver();
        return;
    }

    snake.unshift(newHead);

    // Check for food collision
    if (newHead.x === food.x && newHead.y === food.y) {
        currentScore++;
        food = getRandomFoodPosition();
        if (currentScore > highScore) {
            highScore = currentScore;
        }
    } else {
        snake.pop();
    }
}

function getRandomFoodPosition() {
    let position;
    do {
        position = {
            x: Math.floor(Math.random() * (width / tileSize)) * tileSize,
            y: Math.floor(Math.random() * (height / tileSize)) * tileSize,
        };
    } while (snake.some(segment => segment.x === position.x && segment.y === position.y));
    return position;
}

function triggerGameOver() {
    gameOver = true;
    isPaused = true;
    setTimeout(() => {
        alert('Game Over! Click OK to restart.');
        resetGame();
    }, 500);  // 0.5 second delay before resetting the game
}

function resetGame() {
    snake = [{ x: 100, y: 100 }];
    direction = { x: 1, y: 0 };
    nextDirection = { x: 1, y: 0 };
    currentScore = 0;
    gameOver = false;
    isPaused = false;
    food = getRandomFoodPosition();
}

function changeDirection(event) {
    const keyPressed = event.keyCode;

    // Avoid moving in the opposite direction directly
    if (keyPressed === 37 && direction.x === 0) { // Left arrow
        nextDirection = { x: -1, y: 0 };
    } else if (keyPressed === 38 && direction.y === 0) { // Up arrow
        nextDirection = { x: 0, y: -1 };
    } else if (keyPressed === 39 && direction.x === 0) { // Right arrow
        nextDirection = { x: 1, y: 0 };
    } else if (keyPressed === 40 && direction.y === 0) { // Down arrow
        nextDirection = { x: 0, y: 1 };
    }
}

document.addEventListener("keydown", changeDirection);

function gameLoop() {
    if (!gameOver) {
        update();
        draw();
    }
    setTimeout(gameLoop, 350); // Control the game speed
}

gameLoop();
